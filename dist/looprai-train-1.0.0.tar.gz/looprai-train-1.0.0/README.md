# A sample Python project for LoopR AI

